(function (doc) {
    'use strict';

    $.getJSON("http://localhost:3000/products", function (data) {
        var items = [];
        $.each(data, function (key, val) {
            items.push("<li id='" + key + "'><span class='row name'>" + val.name + "</span><span class='row category'>" + val.category + "</span><span class='row price'>$ " + val.price + "</span></li>");
        });

        $("<ul/>", {
            html: items.join("")
        }).appendTo('.product-list-container');

    });


}(window.document));