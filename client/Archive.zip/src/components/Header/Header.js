(function(doc) {
  'use strict';

  console.log('works!');


}(window.document));